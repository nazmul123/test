##Todo app using Express.js

Simple Todo app using Express JS and mongoDB as a database.

So install the following tools

- node
- mongoDB
- npm

Then run the following command

     $1: npm install   // To install all the node packages
     
     $2: npm install -g bower // Install bower, If not already installed
     
     $3: bower install  // To install front end dependencies
     
     $4: npm install -g nodemon // To see the Live change
     
     $4: nodemon app.js  // To RUN the app. 

Then Browse http://localhost:3000/ . You will see the Homepage.

For more details you can see [My Personal Blog](http://nazmultune.wordpress.com)

Explore the Express :)
